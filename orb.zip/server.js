const express = require("express");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Pool } = require("pg");
const { AccessToken } = require("livekit-server-sdk");

const app = express();
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes("localhost")
    ? { rejectUnauthorized: false } : false
});

const JWT_SECRET = process.env.JWT_SECRET;
const PORT = process.env.PORT || 3000;
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username VARCHAR(32) UNIQUE NOT NULL,
      display_name VARCHAR(80) NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS rooms (
      id SERIAL PRIMARY KEY,
      owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title VARCHAR(100) NOT NULL,
      room_key VARCHAR(80) UNIQUE NOT NULL,
      password_hash TEXT,
      guest_enabled BOOLEAN NOT NULL DEFAULT false,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS room_members (
      room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role VARCHAR(20) NOT NULL DEFAULT 'student',
      added_at TIMESTAMPTZ DEFAULT NOW(),
      PRIMARY KEY(room_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS rooms_owner_idx ON rooms(owner_id);
    CREATE INDEX IF NOT EXISTS room_members_user_idx ON room_members(user_id);
    CREATE TABLE IF NOT EXISTS room_messages (
      id BIGSERIAL PRIMARY KEY, room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, display_name VARCHAR(80) NOT NULL,
      body TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS room_board_events (
      id BIGSERIAL PRIMARY KEY, room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      event JSONB NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS quizzes (
      id SERIAL PRIMARY KEY, room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      title VARCHAR(140) NOT NULL, questions JSONB NOT NULL, created_by INTEGER REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS quiz_submissions (
      id BIGSERIAL PRIMARY KEY, quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, guest_name VARCHAR(80),
      answers JSONB NOT NULL, score INTEGER NOT NULL DEFAULT 0, submitted_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS room_polls (
      id SERIAL PRIMARY KEY, room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      question VARCHAR(240) NOT NULL, options JSONB NOT NULL, created_by INTEGER REFERENCES users(id),
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS poll_votes (
      id BIGSERIAL PRIMARY KEY, poll_id INTEGER NOT NULL REFERENCES room_polls(id) ON DELETE CASCADE,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, guest_key VARCHAR(80),
      option_index INTEGER NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS room_files (
      id BIGSERIAL PRIMARY KEY, room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      uploader_id INTEGER REFERENCES users(id), file_name VARCHAR(255) NOT NULL,
      object_key TEXT NOT NULL, content_type VARCHAR(120), size_bytes BIGINT, created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS room_messages_idx ON room_messages(room_id, created_at);
    CREATE INDEX IF NOT EXISTS room_board_idx ON room_board_events(room_id, id);
    CREATE UNIQUE INDEX IF NOT EXISTS poll_one_vote_user ON poll_votes(poll_id,user_id) WHERE user_id IS NOT NULL;
  `);
}

function makeToken(user) {
  return jwt.sign({ id: user.id, username: user.username, displayName: user.display_name }, JWT_SECRET, { expiresIn: "7d" });
}
function setAuth(res, token) {
  res.cookie("orb_session", token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "lax", maxAge: 7 * 24 * 60 * 60 * 1000
  });
}
function requireAuth(req, res, next) {
  try {
    const token = req.cookies.orb_session;
    if (!token) return res.status(401).json({ error: "ابتدا وارد حساب کاربری شوید." });
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { return res.status(401).json({ error: "نشست شما منقضی شده است؛ دوباره وارد شوید." }); }
}
const clean = (s, max=100) => String(s || "").trim().slice(0, max);
const slug = () => crypto.randomBytes(8).toString("hex");

app.get("/health", (req, res) => res.json({ ok: true, service: "ORB BIN" }));

app.post("/api/register", authLimiter, async (req, res) => {
  try {
    const username = clean(req.body.username, 32).toLowerCase();
    const displayName = clean(req.body.displayName, 80);
    const password = String(req.body.password || "");
    if (!/^[a-z0-9_.-]{3,32}$/.test(username)) return res.status(400).json({ error: "نام کاربری باید ۳ تا ۳۲ کاراکتر و شامل حروف انگلیسی، عدد، نقطه، خط تیره یا زیرخط باشد." });
    if (displayName.length < 2) return res.status(400).json({ error: "نام نمایشی را وارد کنید." });
    if (password.length < 8) return res.status(400).json({ error: "رمز عبور باید حداقل ۸ کاراکتر باشد." });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(username, display_name, password_hash) VALUES($1,$2,$3) RETURNING id,username,display_name",
      [username, displayName, hash]
    );
    setAuth(res, makeToken(result.rows[0]));
    res.json({ user: result.rows[0] });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "این نام کاربری قبلاً ثبت شده است." });
    console.error(e); res.status(500).json({ error: "ثبت‌نام انجام نشد." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  try {
    const username = clean(req.body.username, 32).toLowerCase();
    const result = await pool.query("SELECT * FROM users WHERE username=$1", [username]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(String(req.body.password || ""), user.password_hash)))
      return res.status(401).json({ error: "نام کاربری یا رمز عبور نادرست است." });
    setAuth(res, makeToken(user));
    res.json({ user: { id: user.id, username: user.username, display_name: user.display_name } });
  } catch (e) { console.error(e); res.status(500).json({ error: "ورود انجام نشد." }); }
});

app.post("/api/logout", (req, res) => { res.clearCookie("orb_session"); res.json({ ok: true }); });
app.get("/api/me", requireAuth, async (req, res) => {
  const r = await pool.query("SELECT id,username,display_name FROM users WHERE id=$1", [req.user.id]);
  res.json({ user: r.rows[0] });
});

app.get("/api/rooms", requireAuth, async (req, res) => {
  const r = await pool.query(`
    SELECT DISTINCT rooms.*, CASE WHEN rooms.owner_id=$1 THEN 'owner' ELSE rm.role END AS my_role,
    (SELECT COUNT(*) FROM room_members x WHERE x.room_id=rooms.id) AS member_count
    FROM rooms LEFT JOIN room_members rm ON rm.room_id=rooms.id AND rm.user_id=$1
    WHERE rooms.owner_id=$1 OR rm.user_id=$1 ORDER BY rooms.created_at DESC
  `, [req.user.id]);
  res.json({ rooms: r.rows });
});

app.post("/api/rooms", requireAuth, async (req, res) => {
  try {
    const title = clean(req.body.title, 100);
    const password = String(req.body.password || "");
    const guestEnabled = Boolean(req.body.guestEnabled);
    if (title.length < 2) return res.status(400).json({ error: "نام کلاس حداقل باید ۲ حرف باشد." });
    if (!guestEnabled && password.length < 4) return res.status(400).json({ error: "برای کلاس رمزدار، رمز حداقل ۴ کاراکتری تعیین کنید." });
    const roomKey = slug();
    const passHash = guestEnabled ? null : await bcrypt.hash(password, 10);
    const result = await pool.query(
      "INSERT INTO rooms(owner_id,title,room_key,password_hash,guest_enabled) VALUES($1,$2,$3,$4,$5) RETURNING *",
      [req.user.id, title, roomKey, passHash, guestEnabled]
    );
    await pool.query("INSERT INTO room_members(room_id,user_id,role) VALUES($1,$2,'teacher')", [result.rows[0].id, req.user.id]);
    res.json({ room: result.rows[0] });
  } catch (e) { console.error(e); res.status(500).json({ error: "ساخت کلاس انجام نشد." }); }
});

async function getRoom(roomKey) {
  const r = await pool.query("SELECT * FROM rooms WHERE room_key=$1", [roomKey]);
  return r.rows[0];
}
async function roomRole(room, userId) {
  if (room.owner_id === userId) return "owner";
  const r = await pool.query("SELECT role FROM room_members WHERE room_id=$1 AND user_id=$2", [room.id, userId]);
  return r.rows[0]?.role || null;
}

app.get("/api/rooms/:key", requireAuth, async (req, res) => {
  const room = await getRoom(req.params.key);
  if (!room) return res.status(404).json({ error: "کلاس پیدا نشد." });
  const role = await roomRole(room, req.user.id);
  if (!role) return res.status(403).json({ error: "شما عضو این کلاس نیستید." });
  const members = await pool.query("SELECT u.username,u.display_name,rm.role FROM room_members rm JOIN users u ON u.id=rm.user_id WHERE rm.room_id=$1 ORDER BY rm.added_at", [room.id]);
  res.json({ room: { id: room.id, title: room.title, room_key: room.room_key, guest_enabled: room.guest_enabled }, role, members: members.rows });
});

app.post("/api/rooms/:key/members", requireAuth, async (req, res) => {
  const room = await getRoom(req.params.key);
  if (!room) return res.status(404).json({ error: "کلاس پیدا نشد." });
  const role = await roomRole(room, req.user.id);
  if (role !== "owner") return res.status(403).json({ error: "فقط سازندهٔ کلاس می‌تواند اعضا را مدیریت کند." });
  const username = clean(req.body.username, 32).toLowerCase();
  const memberRole = ["teacher","student","moderator"].includes(req.body.role) ? req.body.role : "student";
  const user = await pool.query("SELECT id FROM users WHERE username=$1", [username]);
  if (!user.rows[0]) return res.status(404).json({ error: "کاربری با این نام پیدا نشد؛ ابتدا باید ثبت‌نام کند." });
  try {
    await pool.query("INSERT INTO room_members(room_id,user_id,role) VALUES($1,$2,$3)", [room.id,user.rows[0].id,memberRole]);
    res.json({ ok: true });
  } catch(e) {
    if (e.code === "23505") return res.status(409).json({ error: "این کاربر از قبل عضو کلاس است." });
    throw e;
  }
});

app.get("/api/public/rooms/:key", async (req, res) => {
  const room = await getRoom(req.params.key);
  if (!room) return res.status(404).json({ error: "کلاس پیدا نشد." });
  res.json({ title: room.title, guest_enabled: room.guest_enabled, has_password: Boolean(room.password_hash) });
});

app.post("/api/rooms/:key/join", async (req, res) => {
  try {
    const room = await getRoom(req.params.key);
    if (!room) return res.status(404).json({ error: "کلاس پیدا نشد." });
    let user = null, role = null, displayName = "";
    const token = req.cookies.orb_session;
    if (token) { try { user = jwt.verify(token, JWT_SECRET); } catch {} }

    if (user) {
      role = await roomRole(room, user.id);
      if (role) {
        displayName = user.displayName;
      } else if (room.guest_enabled) {
        displayName = clean(req.body.displayName || user.displayName, 50);
        role = "guest";
      } else {
        const pass = String(req.body.password || "");
        if (!room.password_hash || !(await bcrypt.compare(pass, room.password_hash)))
          return res.status(401).json({ error: "برای ورود، رمز کلاس را درست وارد کنید." });
        displayName = clean(req.body.displayName || user.displayName, 50);
        role = "guest";
      }
    } else {
      displayName = clean(req.body.displayName, 50);
      if (displayName.length < 2) return res.status(400).json({ error: "یک نام نمایشی انتخاب کنید." });
      if (room.guest_enabled) {
        role = "guest";
      } else {
        const pass = String(req.body.password || "");
        if (!room.password_hash || !(await bcrypt.compare(pass, room.password_hash)))
          return res.status(401).json({ error: "رمز کلاس اشتباه است." });
        role = "guest";
      }
    }

    if (!process.env.LIVEKIT_URL || !process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET)
      return res.status(503).json({ error: "سرویس تماس هنوز تنظیم نشده است؛ مدیر سامانه باید اطلاعات LiveKit را وارد کند." });
    const identity = user && role !== "guest" ? `user-${user.id}` : `guest-${crypto.randomBytes(6).toString("hex")}`;
    const at = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, { identity, name: displayName, ttl: "2h" });
    at.addGrant({ roomJoin: true, room: room.room_key, canPublish: true, canSubscribe: true, canPublishData: true });
    const lkToken = await at.toJwt();
    res.json({ token: lkToken, serverUrl: process.env.LIVEKIT_URL, roomName: room.room_key, displayName, role, title: room.title });
  } catch(e) { console.error(e); res.status(500).json({ error: "ورود به کلاس انجام نشد." }); }
});


// Durable chat history for signed-in room members
app.get("/api/rooms/:key/messages", requireAuth, async (req,res) => {
  const room = await getRoom(req.params.key);
  if (!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  if (!(await roomRole(room, req.user.id))) return res.status(403).json({error:"عضو این کلاس نیستید."});
  const r = await pool.query("SELECT id,display_name,body,created_at FROM room_messages WHERE room_id=$1 ORDER BY id DESC LIMIT 100",[room.id]);
  res.json({messages:r.rows.reverse()});
});
app.post("/api/rooms/:key/messages", requireAuth, async (req,res) => {
  const room = await getRoom(req.params.key);
  if (!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  if (!(await roomRole(room, req.user.id))) return res.status(403).json({error:"عضو این کلاس نیستید."});
  const body = clean(req.body.body,2000);
  if (!body) return res.status(400).json({error:"متن پیام خالی است."});
  const r = await pool.query("INSERT INTO room_messages(room_id,user_id,display_name,body) VALUES($1,$2,$3,$4) RETURNING id,display_name,body,created_at",[room.id,req.user.id,req.user.displayName,body]);
  res.json({message:r.rows[0]});
});

// Persistent whiteboard event stream (stroke and clear)
app.get("/api/rooms/:key/board", requireAuth, async (req,res) => {
  const room=await getRoom(req.params.key);
  if(!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  if(!(await roomRole(room,req.user.id))) return res.status(403).json({error:"عضو این کلاس نیستید."});
  const r=await pool.query("SELECT event FROM room_board_events WHERE room_id=$1 ORDER BY id DESC LIMIT 300",[room.id]);
  res.json({events:r.rows.reverse().map(x=>x.event)});
});
app.post("/api/rooms/:key/board", requireAuth, async (req,res) => {
  const room=await getRoom(req.params.key);
  if(!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  if(!(await roomRole(room,req.user.id))) return res.status(403).json({error:"عضو این کلاس نیستید."});
  const event=req.body.event;
  if(!event || !["stroke","clear"].includes(event.type)) return res.status(400).json({error:"رویداد تخته معتبر نیست."});
  await pool.query("INSERT INTO room_board_events(room_id,event) VALUES($1,$2)",[room.id,JSON.stringify(event)]);
  res.json({ok:true});
});

// Teacher-created quizzes with multiple-choice questions
app.get("/api/rooms/:key/quizzes", requireAuth, async (req,res) => {
  const room=await getRoom(req.params.key);
  if(!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  if(!(await roomRole(room,req.user.id))) return res.status(403).json({error:"عضو این کلاس نیستید."});
  const r=await pool.query("SELECT id,title,questions,created_at FROM quizzes WHERE room_id=$1 ORDER BY id DESC",[room.id]);
  res.json({quizzes:r.rows.map(q=>({...q,questions:q.questions.map(({text,options})=>({text,options}))}))});
});
app.post("/api/rooms/:key/quizzes", requireAuth, async (req,res) => {
  const room=await getRoom(req.params.key);
  if(!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  const role=await roomRole(room,req.user.id);
  if(!["owner","teacher","moderator"].includes(role)) return res.status(403).json({error:"فقط مدرس یا مدیر می‌تواند آزمون بسازد."});
  const title=clean(req.body.title,140), questions=Array.isArray(req.body.questions)?req.body.questions:[];
  if(title.length<2 || !questions.length || questions.length>30) return res.status(400).json({error:"عنوان و حداقل یک سؤال لازم است (حداکثر ۳۰ سؤال)."});
  const safe=[];
  for(const q of questions){
    const text=clean(q.text,500), options=Array.isArray(q.options)?q.options.map(x=>clean(x,180)).filter(Boolean):[];
    const correct=Number(q.correct);
    if(!text || options.length<2 || options.length>6 || !Number.isInteger(correct) || correct<0 || correct>=options.length)
      return res.status(400).json({error:"هر سؤال باید متن، ۲ تا ۶ گزینه و پاسخ صحیح معتبر داشته باشد."});
    safe.push({text,options,correct});
  }
  const r=await pool.query("INSERT INTO quizzes(room_id,title,questions,created_by) VALUES($1,$2,$3,$4) RETURNING id,title,created_at",[room.id,title,JSON.stringify(safe),req.user.id]);
  res.json({quiz:r.rows[0]});
});
app.post("/api/quizzes/:id/submit", requireAuth, async (req,res) => {
  const quiz=await pool.query("SELECT q.*,r.room_key FROM quizzes q JOIN rooms r ON r.id=q.room_id WHERE q.id=$1",[req.params.id]);
  if(!quiz.rows[0]) return res.status(404).json({error:"آزمون پیدا نشد."});
  const q=quiz.rows[0], role=await roomRole({id:q.room_id,owner_id:q.owner_id},req.user.id);
  if(!role) return res.status(403).json({error:"عضو کلاس نیستید."});
  const answers=Array.isArray(req.body.answers)?req.body.answers:[];
  const score=q.questions.reduce((n,item,i)=>n+(Number(answers[i])===item.correct?1:0),0);
  await pool.query("INSERT INTO quiz_submissions(quiz_id,user_id,answers,score) VALUES($1,$2,$3,$4)",[q.id,req.user.id,JSON.stringify(answers),score]);
  res.json({score,total:q.questions.length});
});

// Polls
app.get("/api/rooms/:key/polls", requireAuth, async (req,res) => {
  const room=await getRoom(req.params.key);
  if(!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  if(!(await roomRole(room,req.user.id))) return res.status(403).json({error:"عضو این کلاس نیستید."});
  const r=await pool.query("SELECT p.id,p.question,p.options,p.created_at,COUNT(v.id)::int AS votes FROM room_polls p LEFT JOIN poll_votes v ON v.poll_id=p.id WHERE p.room_id=$1 GROUP BY p.id ORDER BY p.id DESC",[room.id]);
  res.json({polls:r.rows});
});
app.post("/api/rooms/:key/polls", requireAuth, async (req,res) => {
  const room=await getRoom(req.params.key);
  if(!room) return res.status(404).json({error:"کلاس پیدا نشد."});
  const role=await roomRole(room,req.user.id);
  if(!["owner","teacher","moderator"].includes(role)) return res.status(403).json({error:"فقط مدرس یا مدیر می‌تواند نظرسنجی بسازد."});
  const question=clean(req.body.question,240), options=Array.isArray(req.body.options)?req.body.options.map(x=>clean(x,120)).filter(Boolean):[];
  if(!question || options.length<2 || options.length>8) return res.status(400).json({error:"سؤال و ۲ تا ۸ گزینه لازم است."});
  const r=await pool.query("INSERT INTO room_polls(room_id,question,options,created_by) VALUES($1,$2,$3,$4) RETURNING id,question,options",[room.id,question,JSON.stringify(options),req.user.id]);
  res.json({poll:r.rows[0]});
});
app.post("/api/polls/:id/vote", requireAuth, async (req,res) => {
  const poll=await pool.query("SELECT p.*,r.owner_id FROM room_polls p JOIN rooms r ON r.id=p.room_id WHERE p.id=$1",[req.params.id]);
  if(!poll.rows[0]) return res.status(404).json({error:"نظرسنجی پیدا نشد."});
  const role=await roomRole({id:poll.rows[0].room_id,owner_id:poll.rows[0].owner_id},req.user.id);
  if(!role) return res.status(403).json({error:"عضو کلاس نیستید."});
  const index=Number(req.body.optionIndex), options=poll.rows[0].options;
  if(!Number.isInteger(index)||index<0||index>=options.length) return res.status(400).json({error:"گزینه معتبر نیست."});
  try { await pool.query("INSERT INTO poll_votes(poll_id,user_id,option_index) VALUES($1,$2,$3)",[req.params.id,req.user.id,index]); }
  catch(e){ if(e.code==="23505") return res.status(409).json({error:"قبلاً در این نظرسنجی رأی داده‌اید."}); throw e; }
  res.json({ok:true});
});

app.get("/room/:key", (req,res) => res.sendFile(path.join(__dirname,"public","room.html")));
app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));

async function start() {
  if (!JWT_SECRET) throw new Error("JWT_SECRET environment variable is required");
  await initDb();
  app.listen(PORT, () => console.log(`ORB BIN listening on ${PORT}`));
}
start().catch(e => { console.error("Startup failed:", e); process.exit(1); });

const $=s=>document.querySelector(s);
const roomKey=location.pathname.split("/").filter(Boolean).pop();
let lkRoom=null, myRole="guest", roomInfo=null, localName="", boardCtx=null, drawing=false, lastPoint=null;
async function api(url,opts={}){const r=await fetch(url,{...opts,headers:{"Content-Type":"application/json",...(opts.headers||{})}});const d=await r.json();if(!r.ok)throw Error(d.error||"خطایی رخ داد");return d}
function tab(name){document.querySelectorAll(".tabs button").forEach(b=>b.classList.toggle("active",b.dataset.tab===name));["people","chat","board","quiz","polls"].forEach(n=>$("#"+n+"Panel").classList.toggle("hidden",n!==name))}
document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>tab(b.dataset.tab));
$("#chatBtn").onclick=()=>tab("chat");$("#whiteboardBtn").onclick=()=>tab("board");$("#quizBtn").onclick=()=>{tab("quiz");loadQuizzes()};$("#pollBtn").onclick=()=>{tab("polls");loadPolls()};

async function loadQuizzes(){
 try{
  const d=await api("/api/rooms/"+roomKey+"/quizzes");const box=$("#quizList");box.innerHTML="";
  d.quizzes.forEach(q=>{const card=document.createElement("div");card.className="message";const h=document.createElement("b");h.textContent=q.title;card.append(h);q.questions.forEach((it,i)=>{const p=document.createElement("p");p.textContent=(i+1)+". "+it.text+" — "+it.options.join(" / ");card.append(p)});box.append(card)});
  $("#quizCreate").classList.toggle("hidden",!["owner","teacher","moderator"].includes(myRole));
 }catch(e){$("#quizList").textContent=e.message}
}
$("#createQuiz").onclick=async()=>{
 try{
  const title=$("#quizTitle").value.trim(), lines=$("#quizQuestions").value.split("\\n").filter(Boolean);
  const questions=lines.map(line=>{const a=line.split("|").map(x=>x.trim());let correct=a.findIndex(x=>x.endsWith("*"));return {text:a[0],options:a.slice(1).map(x=>x.replace(/\\*$/,"")),correct}});
  await api("/api/rooms/"+roomKey+"/quizzes",{method:"POST",body:JSON.stringify({title,questions})});$("#quizTitle").value="";$("#quizQuestions").value="";loadQuizzes();
 }catch(e){alert(e.message)}
};
async function loadPolls(){
 try{
  const d=await api("/api/rooms/"+roomKey+"/polls");const box=$("#pollList");box.innerHTML="";
  d.polls.forEach(p=>{const card=document.createElement("div");card.className="message";const h=document.createElement("b");h.textContent=p.question;card.append(h);p.options.forEach((op,i)=>{const b=document.createElement("button");b.className="btn outline full";b.textContent=op;b.onclick=async()=>{try{await api("/api/polls/"+p.id+"/vote",{method:"POST",body:JSON.stringify({optionIndex:i})});b.textContent+=" ✓";b.disabled=true}catch(e){alert(e.message)}};card.append(b)});box.append(card)});
  $("#pollCreate").classList.toggle("hidden",!["owner","teacher","moderator"].includes(myRole));
 }catch(e){$("#pollList").textContent=e.message}
}
$("#createPoll").onclick=async()=>{try{await api("/api/rooms/"+roomKey+"/polls",{method:"POST",body:JSON.stringify({question:$("#pollQuestion").value,options:$("#pollOptions").value.split("|")})});$("#pollQuestion").value="";$("#pollOptions").value="";loadPolls()}catch(e){alert(e.message)}};
$("#handBtn").onclick=()=>{if(!lkRoom)return;const msg=JSON.stringify({type:"hand",name:localName});lkRoom.localParticipant.publishData(new TextEncoder().encode(msg),{reliable:true});$("#handBtn").classList.toggle("active")};

function addMessage(name,text){const d=document.createElement("div");d.className="message";const b=document.createElement("b");b.textContent=name;const p=document.createElement("p");p.textContent=text;d.append(b,p);$("#messages").append(d);$("#messages").scrollTop=$("#messages").scrollHeight}
function renderPeople(){const list=$("#peopleList");list.innerHTML="";const p=document.createElement("div");p.className="person";p.textContent="● "+localName+" (شما · "+myRole+")";list.append(p);if(lkRoom)lkRoom.remoteParticipants.forEach(part=>{const x=document.createElement("div");x.className="person";x.textContent="● "+(part.name||part.identity);list.append(x)})}
function addTrack(track,participant){const grid=$("#videoGrid");let tile=document.querySelector(`[data-participant="${participant.identity}"]`);if(!tile){tile=document.createElement("div");tile.className="video-tile";tile.dataset.participant=participant.identity;const label=document.createElement("span");label.className="tile-name";label.textContent=participant.name||participant.identity;tile.append(label);grid.querySelector(".connecting")?.remove();grid.append(tile)}if(track.kind==="video"){const el=track.attach();el.autoplay=true;el.playsInline=true;tile.prepend(el)}}
async function connect(){
 try{
  const me=await fetch("/api/me");let logged=me.ok;
  const pub=await api("/api/public/rooms/"+roomKey);
  $("#roomTitle").textContent=pub.title;
  $("#classPasswordWrap").classList.toggle("hidden",pub.guest_enabled);
  const info=await api("/api/rooms/"+roomKey).catch(()=>null);
  if(info){roomInfo=info.room;myRole=info.role;$("#memberManage").classList.toggle("hidden",myRole!=="owner");}
  $("#guestModal").classList.add("show");
 }catch{$("#guestModal").classList.add("show")}
}
$("#guestForm").onsubmit=async e=>{e.preventDefault();$("#guestError").textContent="";try{
 localName=$("#guestName").value.trim();
 const d=await api("/api/rooms/"+roomKey+"/join",{method:"POST",body:JSON.stringify({displayName:localName,password:$("#classPassword").value})});
 localName=d.displayName;myRole=d.role;$("#roomTitle").textContent=d.title;$("#guestModal").classList.remove("show");await startLive(d);await loadQuizzes();await loadPolls();await loadHistory();
 }catch(err){$("#guestError").textContent=err.message}};
async function startLive(d){
 if(!window.LivekitClient){$("#roomStatus").textContent="کتابخانهٔ تماس بارگذاری نشد.";return}
 const {Room,RoomEvent,Track}=LivekitClient;
 lkRoom=new Room({adaptiveStream:true,dynacast:true});
 lkRoom.on(RoomEvent.TrackSubscribed,(track,publication,participant)=>addTrack(track,participant));
 lkRoom.on(RoomEvent.TrackUnsubscribed,(track,publication,participant)=>{track.detach().forEach(el=>el.remove())});
 lkRoom.on(RoomEvent.ParticipantConnected,renderPeople);lkRoom.on(RoomEvent.ParticipantDisconnected,renderPeople);
 lkRoom.on(RoomEvent.DataReceived,(payload,participant)=>{try{const msg=JSON.parse(new TextDecoder().decode(payload));if(msg.type==="chat")addMessage(msg.name,msg.text);if(msg.type==="board")drawRemote(msg);if(msg.type==="clear")ctx.clearRect(0,0,canvas.width,canvas.height);if(msg.type==="hand")addMessage("سیستم",msg.name+" دستش را بلند کرد.")}catch{}});
 await lkRoom.connect(d.serverUrl,d.token);$("#roomStatus").textContent="متصل · "+myRole;
 if(["owner","teacher","moderator"].includes(myRole)){try{await lkRoom.localParticipant.setMicrophoneEnabled(true);await lkRoom.localParticipant.setCameraEnabled(true)}catch(e){console.warn(e)}}
 lkRoom.remoteParticipants.forEach(p=>p.trackPublications.forEach(pub=>{if(pub.track)addTrack(pub.track,p)}));renderPeople();
}
$("#micBtn").onclick=async()=>{try{const on=lkRoom.localParticipant.isMicrophoneEnabled;await lkRoom.localParticipant.setMicrophoneEnabled(!on);$("#micBtn").classList.toggle("active",!on)}catch(e){alert(e.message)}};
$("#camBtn").onclick=async()=>{try{const on=lkRoom.localParticipant.isCameraEnabled;await lkRoom.localParticipant.setCameraEnabled(!on);$("#camBtn").classList.toggle("active",!on)}catch(e){alert(e.message)}};
$("#shareBtn").onclick=async()=>{try{await lkRoom.localParticipant.setScreenShareEnabled(true)}catch(e){alert("اشتراک صفحه در این مرورگر یا دستگاه پشتیبانی نمی‌شود.")}};
$("#leaveBtn").onclick=async()=>{if(lkRoom)await lkRoom.disconnect();location.href="/"};
$("#copyRoomLink").onclick=async()=>{await navigator.clipboard.writeText(location.href);$("#copyRoomLink").textContent="کپی شد ✓";setTimeout(()=>$("#copyRoomLink").textContent="کپی لینک دعوت",1600)};
$("#chatForm").onsubmit=async e=>{e.preventDefault();const text=$("#chatInput").value.trim();if(!text||!lkRoom)return;const payload=new TextEncoder().encode(JSON.stringify({type:"chat",name:localName,text}));await lkRoom.localParticipant.publishData(payload,{reliable:true});addMessage(localName,text);api("/api/rooms/"+roomKey+"/messages",{method:"POST",body:JSON.stringify({body:text})}).catch(()=>{});$("#chatInput").value=""};
$("#addMember").onclick=async()=>{try{await api("/api/rooms/"+roomKey+"/members",{method:"POST",body:JSON.stringify({username:$("#memberUsername").value,role:$("#memberRole").value})});$("#memberError").textContent="عضو اضافه شد؛ اکنون می‌تواند با حسابش وارد شود."}catch(e){$("#memberError").textContent=e.message}};
async function loadHistory(){try{const d=await api("/api/rooms/"+roomKey+"/messages");d.messages.forEach(m=>addMessage(m.display_name,m.body))}catch{}try{const d=await api("/api/rooms/"+roomKey+"/board");d.events.forEach(ev=>{if(ev.type==="stroke")drawRemote({a:ev.a,b:ev.b});else if(ev.type==="clear")ctx.clearRect(0,0,canvas.width,canvas.height)})}catch{}}
const canvas=$("#board"),ctx=canvas.getContext("2d");ctx.lineWidth=3;ctx.lineCap="round";ctx.strokeStyle="#172c43";
function point(e){const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
function sendBoard(a,b){if(!lkRoom)return;const event={type:"stroke",a,b};lkRoom.localParticipant.publishData(new TextEncoder().encode(JSON.stringify({type:"board",a,b})),{reliable:true});api("/api/rooms/"+roomKey+"/board",{method:"POST",body:JSON.stringify({event})}).catch(()=>{})}
function drawRemote(m){ctx.beginPath();ctx.moveTo(m.a.x,m.a.y);ctx.lineTo(m.b.x,m.b.y);ctx.stroke()}
canvas.onpointerdown=e=>{drawing=true;lastPoint=point(e);canvas.setPointerCapture(e.pointerId)};
canvas.onpointermove=e=>{if(!drawing)return;const p=point(e);ctx.beginPath();ctx.moveTo(lastPoint.x,lastPoint.y);ctx.lineTo(p.x,p.y);ctx.stroke();sendBoard(lastPoint,p);lastPoint=p};
canvas.onpointerup=()=>drawing=false;canvas.onpointercancel=()=>drawing=false;
$("#clearBoard").onclick=()=>{ctx.clearRect(0,0,canvas.width,canvas.height);if(lkRoom){lkRoom.localParticipant.publishData(new TextEncoder().encode(JSON.stringify({type:"clear"})),{reliable:true});api("/api/rooms/"+roomKey+"/board",{method:"POST",body:JSON.stringify({event:{type:"clear"}})}).catch(()=>{})}};
connect();